#include <iostream>

using namespace std;

int main(){
    float number1,number2;
// entrada que irá receber number1
        cin >> number1;

//entrada que irá receber o number2;
        cin >> number2;

        cout << (number1 + number2)/2;
/* saida que irá exibir o resultado de nunber1 e nunber 2.
e dividir pelo tanto de vezes que se repete*/ }